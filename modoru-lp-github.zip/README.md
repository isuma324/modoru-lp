# MODORU LP

This is the landing page for MODORU, built with static HTML.